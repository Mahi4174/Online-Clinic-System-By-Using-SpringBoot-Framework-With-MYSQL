package com.wipro.service;

import com.wipro.model.User;

public interface UserService {
	void registerUser(User user);
	
	User findUserById(String userId);
	
	User updateUser(User user);

}
