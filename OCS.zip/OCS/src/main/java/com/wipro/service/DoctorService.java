package com.wipro.service;

import java.util.List;

import com.wipro.model.Doctor;


public interface DoctorService {
	List<Doctor> getAllDoctors();
	
	Doctor saveDoctor(Doctor doctor);
	
	Doctor getDoctorById(int doctorId);
	
	Doctor updateDoctor(Doctor doctor);
	
	void deleteDoctorById(int doctorId);
	
	boolean ifDoctorPresent(int doctorId);
}