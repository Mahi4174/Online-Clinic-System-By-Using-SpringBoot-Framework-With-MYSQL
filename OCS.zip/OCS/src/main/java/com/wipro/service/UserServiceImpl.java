package com.wipro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.dao.UserDao;
import com.wipro.model.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDao userDao;

	@Override
	public void registerUser(User user) {
		userDao.save(user);
		
	}

	@Override
	public User findUserById(String userId) {
		return userDao.findById(userId).orElse(null);
	}

	@Override
	public User updateUser(User user) {
		return userDao.save(user);
	}
	
	
	

}
