package com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.dao.AppointmentDao;
import com.wipro.dao.AppointmentModifyDao;
import com.wipro.model.Appointment;

@Service
public class AppointmentServiceImpl implements AppointmentService {
	
	@Autowired
	AppointmentDao appointmentDao;
	
	@Autowired
	AppointmentModifyDao appointmentModifyDao;

	@Override
	public List<Appointment> getAllAppointment(String userName) {
		return appointmentDao.findByUserId(userName);
	}

	@Override
	public Appointment placeAppointment(Appointment appointment) {
		return appointmentDao.save(appointment);
	}

	@Override
	public boolean ifAppointmentPresent(long appointmentId) {
		return appointmentDao.existsById(appointmentId);
	}

	@Override
	public List<Appointment> getAppointment(int doctorId) {
		return appointmentModifyDao.getAppointment(doctorId);
	}

	@Override
	public List<Appointment> getByDoctorId(int doctorId) {
		return appointmentDao.findByDoctorId(doctorId);
	}
	

}
