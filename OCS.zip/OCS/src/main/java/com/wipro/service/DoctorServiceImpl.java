package com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.dao.DoctorDao;
import com.wipro.model.Doctor;

@Service
public class DoctorServiceImpl implements DoctorService{

	@Autowired
	DoctorDao doctorDao;

	@Override
	public List<Doctor> getAllDoctors() {
		return (List<Doctor>) doctorDao.findAll();
	}

	@Override
	public Doctor saveDoctor(Doctor doctor) {
		return doctorDao.save(doctor);
	}
	

	@Override
	public Doctor getDoctorById(int doctorId) {
		return doctorDao.findById(doctorId).orElse(null);
	}

	@Override
	public Doctor updateDoctor(Doctor doctor) {
		return doctorDao.save(doctor);
	}

	@Override
	public void deleteDoctorById(int doctorId) {
		doctorDao.deleteById(doctorId);
		
	}

	@Override
	public boolean ifDoctorPresent(int doctorId) {
		return doctorDao.existsById(doctorId);
	}

	
	
	
}
