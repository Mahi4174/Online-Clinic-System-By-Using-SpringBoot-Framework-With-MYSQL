package com.wipro.service;

import java.util.List;

import com.wipro.model.Appointment;

public interface AppointmentService {
	List<Appointment> getAllAppointment(String userName);
	Appointment placeAppointment(Appointment appointment);
	
	boolean ifAppointmentPresent(long appointmentId);
	
	List<Appointment> getAppointment(int doctorId);
	
	List<Appointment> getByDoctorId(int doctorId);

}
