package com.wipro.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PatientDetails {
	@Id
	String fullName;
	int age;
	String gender;
	String symptom;
	
	
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSymptom() {
		return symptom;
	}
	public void setSymptom(String symptom) {
		this.symptom = symptom;
	}
	@Override
	public String toString() {
		return "PatientDetails [fullName=" + fullName + ", age=" + age + ", gender=" + gender + ", symptom=" + symptom
				+ "]";
	}
	public PatientDetails(String fullName, int age, String gender, String symptom) {
		super();
		this.fullName = fullName;
		this.age = age;
		this.gender = gender;
		this.symptom = symptom;
	}
	public PatientDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
