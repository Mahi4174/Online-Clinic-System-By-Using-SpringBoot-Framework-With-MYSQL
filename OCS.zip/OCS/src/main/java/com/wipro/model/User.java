package com.wipro.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class User {

	@Id
	@Size(min=8,max=20,message="The username should contains 8-20 characters")
	String userId;
	
	
	@Size(min=8,max=20,message="The password should contains 8-20 characters")
	String password;
	
	@Size(min=4,max=20,message="The name should contains 4-20 characters")
	String name;
	
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	Date DOB;
	
	String gender;
	
	String presentAddress;
	
	String permanentAddress;
	
	
	long phoneNumber;
	
	@Email(message = "Enter a vlaid emailId")
	String emailId;
	
	String userType;
	
	int loginStatus;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPresentAddress() {
		return presentAddress;
	}

	public void setPresentAddress(String presentAddress) {
		this.presentAddress = presentAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNUmber) {
		this.phoneNumber = phoneNUmber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public int getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(int loginStatus) {
		this.loginStatus = loginStatus;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", name=" + name + ", DOB=" + DOB + ", gender="
				+ gender + ", presentAddress=" + presentAddress + ", permanentAddress=" + permanentAddress
				+ ", phoneNUmber=" + phoneNumber + ", emailId=" + emailId + ", userType=" + userType + ", loginStatus="
				+ loginStatus + "]";
	}

	public User(String userId, String password, String name, Date dOB, String gender, String presentAddress,
			String permanentAddress, long phoneNUmber, String emailId, String userType, int loginStatus) {
		super();
		this.userId = userId;
		this.password = password;
		this.name = name;
		DOB = dOB;
		this.gender = gender;
		this.presentAddress = presentAddress;
		this.permanentAddress = permanentAddress;
		this.phoneNumber = phoneNUmber;
		this.emailId = emailId;
		this.userType = userType;
		this.loginStatus = loginStatus;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
