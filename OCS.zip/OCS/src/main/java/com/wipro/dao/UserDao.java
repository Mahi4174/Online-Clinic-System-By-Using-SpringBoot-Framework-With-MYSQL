package com.wipro.dao;

import org.springframework.data.repository.CrudRepository;

import com.wipro.model.User;

public interface UserDao extends CrudRepository<User, String> {

}
