package com.wipro.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.wipro.model.Appointment;

@Repository
public class AppointmentModifyDaoImpl implements AppointmentModifyDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public List<Appointment> getAppointment(int doctorId) {
		String sqlQuery="from Appointment where doctorId=:doctorId";
		Session session=sessionFactory.openSession();
		
		Query<Appointment> query=session.createQuery(sqlQuery);
		query.setParameter("doctorId", doctorId);
		return query.list();
	}

}
