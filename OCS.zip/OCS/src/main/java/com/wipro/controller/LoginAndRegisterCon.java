package com.wipro.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.dao.AppointmentModifyDaoImpl;
import com.wipro.model.Appointment;
import com.wipro.model.User;
import com.wipro.service.AppointmentService;
import com.wipro.service.UserService;

@Controller
public class LoginAndRegisterCon {

	@Autowired
	UserService userService;
	
	@Autowired
	AppointmentService appointmentService;

	static User tempUser;

	@RequestMapping("/")
	public ModelAndView loginAndRegister() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("user", new User());
		mv.setViewName("Login");
		return mv;
	}

	@RequestMapping("/validateLogin")
	public String login(@Valid @ModelAttribute("user") User user, HttpSession session, Model m,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "Login";
		} else {
			User original = userService.findUserById(user.getUserId());
			System.out.println(user.getUserId());
			if (original == null) {
				m.addAttribute("failureMsg", "Invalid Username or Password!!!");
				return "Login";
			} else {
				if (original.getUserId().equals(user.getUserId())
						&& original.getPassword().equals(user.getPassword())) {
					if (original.getLoginStatus() == 0) {
						if ((original.getUserType().toLowerCase()).equals("admin")) {
							session.setAttribute("userName", user.getUserId());
							session.setAttribute("password", user.getPassword());
							original.setLoginStatus(2);
							userService.updateUser(original);
							tempUser = user;
							session.setAttribute("loggedUser", original);
							System.out.println("Successfully LogedIn....");
							return "redirect:displayDoctor";

						} else {
							session.setAttribute("userName", user.getUserId());
							session.setAttribute("password", user.getPassword());
							original.setLoginStatus(2);
							userService.updateUser(original);
							tempUser = user;
							session.setAttribute("loggedUser", original);
							
							return "redirect:userHome";
						}
					} else {
						m.addAttribute("failureMsg", "You already logged in another System");
						return "Login";
					}
				} else {
					m.addAttribute("failureMsg", "Invalid Username or password");
					return "Login";
				}
			}
		}
	}

	@RequestMapping("/RegisterForm")
	public ModelAndView registerForm() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("user", new User());
		mv.setViewName("Register");
		return mv;
	}

	@RequestMapping("/Register")
	public String register(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model m) {
		if (bindingResult.hasErrors()) {
			return "Register";
		} else {
			user.setUserType("user");
			userService.registerUser(user);
			m.addAttribute("msg", "Registered Successully");
			return "redirect:";
		}

	}

	@RequestMapping("/logOut")
	public String logout(HttpSession session,Model m) {
		User original=(User)session.getAttribute("loggedUser");
		System.out.println(original);
		if (original.getLoginStatus() == 1) {
			original.setLoginStatus(0);
			userService.updateUser(original);
			m.addAttribute("successMsg", "Logged out Successfully!!!");
			return "redirect:";
		}
		return "redirect:";
	}
	
	@RequestMapping("/showProfile")
	public String showProfile(Model m,HttpSession session) {
		m.addAttribute("loggedUser",session.getAttribute("loggedUser") );
		return "showProfile";
	}
	
	@RequestMapping("/passwordChangeForm")
	public String changePasswordForm(Model m,HttpSession session) {
		User original=(User)session.getAttribute("loggedUser");
		User sending=new User();
		sending.setUserId(original.getUserId());
		m.addAttribute("user", new User());
		return "passwordForm";
	}
	
	@RequestMapping("/passwordChange")
	public String changePassword(@RequestParam("newPassword")String newPassword,@RequestParam("confirmPassword")String confirmPassword,@ModelAttribute("user")User user,HttpSession session,Model m) {
		User original=(User)session.getAttribute("loggedUser");
		if(!(user.getPassword().equals(original.getPassword()))) {
			m.addAttribute("failureMsg","Old password Wrong!!");
			return "passwordForm";
		}
		else {
			if(!(newPassword.equals(confirmPassword))) {
				m.addAttribute("failureMsg", "Password Mismatch");
				return "passwordForm";
			}
			else {
				original.setPassword(newPassword);
				userService.updateUser(original);
				m.addAttribute("successMsg", "Password Changed Successfully!!");
				return "passwordForm";
			}
		}
	}
	
	@RequestMapping("/goHome")
	public String goHome(HttpSession session,Model m) {
		User user=(User)session.getAttribute("loggedUser");
		if((user.getUserType().toLowerCase()).equals("admin")) {
			return "redirect:displayDoctor";
		}
		else {
			List<Appointment> appointments = appointmentService
					.getAllAppointment((String) session.getAttribute("userName"));
			m.addAttribute("appointments", appointments);
			return "UserHomePage";
		}
	}

}
