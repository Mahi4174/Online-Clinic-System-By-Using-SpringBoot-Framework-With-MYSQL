package com.wipro.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.model.Appointment;
import com.wipro.model.Doctor;
import com.wipro.service.AppointmentService;
import com.wipro.service.DoctorService;

@Controller
public class AppointmentController {

	@Autowired
	AppointmentService appointmentService;

	@Autowired
	DoctorService doctorService;

	static ArrayList<String> getTimeList() {
		ArrayList<String> list = new ArrayList<String>();
		list.add("09:00 AM");
		list.add("09:30 AM");
		list.add("10:00 AM");
		list.add("10:30 AM");
		list.add("11:00 AM");
		list.add("11:30 AM");
		list.add("12:00 PM");
		list.add("01:30 PM");
		list.add("02:00 PM");
		list.add("02:30 PM");
		list.add("03:00 PM");
		list.add("03:30 PM");
		list.add("04:00 PM");
		list.add("04:30 PM");
		list.add("05:00 PM");
		return list;
	}

	@RequestMapping("/userHome")
	public ModelAndView userHome(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		List<Appointment> appointments = appointmentService
				.getAllAppointment((String) session.getAttribute("userName"));
		mv.addObject("appointments", appointments);
		mv.setViewName("UserHomePage");
		return mv;
	}

	@RequestMapping("/fixAppointmentForm")
	public ModelAndView fixForm(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		Appointment appointment = new Appointment();
		appointment.setUserId((String) session.getAttribute("userName"));
		System.out.println((String) session.getAttribute("userName"));
		mv.addObject("app", appointment);
		List<Doctor> doctors = doctorService.getAllDoctors();
		mv.addObject("times", getTimeList());

		mv.addObject("doctors", doctors);
		mv.setViewName("AppointmentFrom");
		return mv;
	}

	@RequestMapping("/fixAppointment")
	public String fixAppointment(@Valid @ModelAttribute("app") Appointment appointment, HttpSession session,
			BindingResult bindingResult, Model m) {
		if (bindingResult.hasErrors()) {
			return "AppointmentFrom";
		} else {
			Date currentDate = new Date(new java.util.Date().getTime());
			if (appointmentService.ifAppointmentPresent(appointment.getAppointmentId())) {
				m.addAttribute("msg", "Appointment ID is already exists");
				List<Doctor> doctors = doctorService.getAllDoctors();
				m.addAttribute("doctors", doctors);
				m.addAttribute("times", getTimeList());
				return "AppointmentFrom";
			}
			if (!doctorService.ifDoctorPresent(appointment.getDoctorId())) {
				m.addAttribute("msg", "Selected Doctor is not in the List");
				List<Doctor> doctors = doctorService.getAllDoctors();
				m.addAttribute("doctors", doctors);
				m.addAttribute("times", getTimeList());
				return "AppointmentFrom";
			}
			if (appointment.getAppointmentDate().compareTo(currentDate) <= 0) {
				System.out.println();
				m.addAttribute("msg", "Appointment date should be futures");
				List<Doctor> doctors = doctorService.getAllDoctors();
				m.addAttribute("doctors", doctors);
				m.addAttribute("times", getTimeList());
				return "AppointmentFrom";
			}
			List<Appointment> appoints = appointmentService.getAppointment(appointment.getDoctorId());
			int count = 0;
			for (int i = 0; i < appoints.size(); i++) {
				if (appointment.getAppointmentDate().compareTo(appoints.get(i).getAppointmentDate()) == 0
						&& appointment.getAppointmentTime().equals(appoints.get(i).getAppointmentTime())) {
					count++;
				}
			}
			if (count == 0) {
				appointment.setUserId((String) session.getAttribute("userName"));
				appointmentService.placeAppointment(appointment);
				m.addAttribute("msg", "Appointment Placed Successfully");
				List<Appointment> appointments = appointmentService
						.getAllAppointment((String) session.getAttribute("userName"));
				m.addAttribute("appointments", appointments);

				return "UserHomePage";

			} else {
				m.addAttribute("msg","Doctor not Avaliable please change the timings");
				List<Doctor> doctors = doctorService.getAllDoctors();
				m.addAttribute("doctors", doctors);
				m.addAttribute("times", getTimeList());
				return "AppointmentFrom";

			}

		}

	}

}
